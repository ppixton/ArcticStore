import React from 'react';
import * as bs from 'react-bootstrap'
import './App.css'
import {
  Link,
  useRouteMatch
} from "react-router-dom"
import PRODUCTS from "./products/src/products"
import ProductCard from './product_card'


function Middle(props) {
    let category_matched = useRouteMatch("/categories/:category");

  return (
    <bs.Container>
        <bs.Row>
            {Object.values(PRODUCTS)
            .filter(
                val => {
                    if (category_matched)
                    {
                        return val.category === category_matched.params.category;
                    }
                    else
                    {
                        return true
                    }
                }).map((product, id) => {
            return (
                <ProductCard product={product} key={id}/>
            )
        })}
        </bs.Row>
    </bs.Container>
    
 );
};
export default Middle;