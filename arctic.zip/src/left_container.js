import React from 'react'
import * as bs from 'react-bootstrap'
import {
    BrowserRouter as Router,
    Switch,
    Route,
    Link
  } from "react-router-dom"
  import PRODUCTS from "./products/src/products"

function left_container(props) {
    const categories = {}
    let total = 0
    for (const p of Object.values(PRODUCTS))
    {
        
        //If the category isn't there set it's value to one
        //If the p.category is already in there- get it's value and add it.
        if (p.category in categories)
        {
          categories[p.category] = categories[p.category] + 1
          total +=1
        }
        else
        {
          categories[p.category] = 1
          total +=1
        }
    }
    return (
        <>
        <div>
          <Link to="/">All Products ({total})</Link>
          {Object.entries(categories).map(([cat, count]) => {
            return (
                <Link key={cat} to={"/categories/" + cat} className="nav-link"> {cat} ({count}) </Link>
            )
          })}
        </div>
        </> 
     );
}
export default left_container