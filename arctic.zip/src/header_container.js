import React from "react";
import {
  BrowserRouter as Router,
  Switch,
  Route,
  Link
} from "react-router-dom"
import * as bs from 'react-bootstrap'

function header_container (props) {
    return (
        <bs.Navbar expand="lg" variant="tabs" style ={{backgroundColor: "#000000", color:"#ffffff"}}>
            <bs.Navbar.Brand href="/">
            <i className="fas fa-snowman" style={{
              color:"white",
            }}></i>
                Arctic
            </bs.Navbar.Brand>
            <bs.Navbar.Toggle aria-controls="basic-navbar-nav" />
            <bs.Navbar.Collapse id="basic-navbar-nav">
                <bs.Nav className="mr-auto">
                <Link to="/Home" className="nav-link">Home</Link>
                <Link to="/Help" className="nav-link">Help</Link>
                <Link to="/About" className="nav-link">About</Link>
                </bs.Nav>
            </bs.Navbar.Collapse>  
            <bs.Navbar.Collapse className="justify-content-end">
                <bs.Navbar.Text>
                Signed in as: <a href="#login">Parker Pixton</a>
                </bs.Navbar.Text>
            </bs.Navbar.Collapse>

            </bs.Navbar>
    )
}

export default header_container