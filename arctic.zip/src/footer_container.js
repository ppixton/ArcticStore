import React from 'react';
import * as bs from 'react-bootstrap'
import './App.css';


function footer(props) {
  return (
    <>
      Arctic &copy; 2020
    </>
 );
}

export default footer;
