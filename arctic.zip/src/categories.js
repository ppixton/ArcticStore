import React from 'react';
import * as bs from 'react-bootstrap'
import './App.css';
import { useRouteMatch } from 'react-router-dom';
import PRODUCTS from './products/src/products';


function categories(props) {
  return (
    <>
      <strong>Recent Purchase History:</strong>
    </>
 );
}

export default categories;
