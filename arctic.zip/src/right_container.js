import React from 'react';
import * as bs from 'react-bootstrap'
import './App.css';


function right(props) {
  return (
    <>
      <strong>Recent Purchase History:</strong>
    </>
 );
}

export default right;
