import React from 'react';
import * as bs from 'react-bootstrap'
import './App.css';
import PRODUCTS from './products/src/products'
import { useRouteMatch } from "react-router-dom"
import { useState } from 'react'

function Product(props) {
  const [img, setImage] = useState(1)
  let match_id = useRouteMatch("/product/:id")
  let item = []
  item = Object.values(PRODUCTS).find(x => x.id === match_id.params.id)

  
  const product_ids = []
  for (let pid of Object.values(PRODUCTS))
  {
    product_ids.push(pid.id)
  }


  let my_error = true
  for (let mid of product_ids)
  {
    if (match_id.params.id === mid)
    {
      my_error = false
    }
  }


  if (my_error === true)
  {
    return (
      <div>Error 404 - Object not found</div>
    )
  }

  return (
    <>
    <div style={{
      float:"right"
    }}>
      <div>
        <bs.Image src={"/product_images/product_images/public/media/products/"+ item.filename + "-" + img + ".png"} style={{
          height: "300px",
          width: "300px"
        }} />
      </div>
        <bs.Image onMouseEnter={() => setImage(1)} src={"/product_images/product_images/public/media/products/"+ item.filename + "-1.png"} style={{
          height: "30px",
          width: "30px",
          margin:"5px"
        }} />
        <bs.Image onMouseEnter={() => setImage(2)} src={"/product_images/product_images/public/media/products/"+ item.filename + "-2.png"} style={{
          height: "30px",
          width: "30px",
          margin:"5px"
        }} />
        <bs.Image onMouseEnter={() => setImage(3)} src={"/product_images/product_images/public/media/products/"+ item.filename + "-3.png"} style={{
          height: "30px",
          width: "30px",
          margin:"5px"
        }} />
        <bs.Image onMouseEnter={() => setImage(4)} src={"/product_images/product_images/public/media/products/"+ item.filename + "-4.png"} style={{
          height: "30px",
          width: "30px",
          margin:"5px"
        }} />
    </div>
      <div style={{
        fontWeight:"bold",
        textAlign: "left",
        fontSize: "40px"

      }}>
        {item.name} <br></br>
        <div style={{
          fontSize: "25px"
        }}>
          ${item.price}
        </div>
        <div style={{
          fontWeight:"normal",
          fontSize:"15px",
          margin:"5px"
        }}>
          <br></br>
          {item.description}
        </div>
      </div>

    </>
 );}

export default Product;